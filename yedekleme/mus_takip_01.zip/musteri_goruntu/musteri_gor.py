from PyQt6.QtWidgets import *
import sys
import os

simdiki_klasor = os.getcwd() #simdiki klasor yolunu donduruyor

sys.path.append(simdiki_klasor) #alttaki kütüphaneyi import etmek icin bu komut kullanılıyor...

# sys.path.append('C:/Users/yildi/OneDrive/Desktop/python/vektorelBilisim/github/musteri_takip_proje03')

import database_islemleri.databaseislem as di

class MusteriGoruntule(QMainWindow):
        def __init__(self):
            super().__init__()

            self.setWindowTitle("Musteri Arama")

            icerik = QVBoxLayout() #main window

            icerik.addWidget(QLabel("Müsteri Adı: ")) #müşteri adı
            self.aranan = QLineEdit()
            icerik.addWidget(self.aranan)
            self.veri = self.aranan.text()

            arama_btn = QPushButton("Ara") #arama butonu
            icerik.addWidget(arama_btn)
            arama_btn.clicked.connect(self.kullaniciBilgiAl)
            
            #aranan isimin bilgilerini yazdır

            araclar = QWidget()
            araclar.setLayout(icerik)
            self.setCentralWidget(araclar)

        
        def kullaniciBilgiAl(self): #burada kaldım
            aranan_text = self.aranan.text() #bilgiyi ekrana yazıyor.
            print(aranan_text) ### 

            self.kullanici_bilgisi = di.kullaniciVeriAl(aranan_text)# 
            print(self.kullanici_bilgisi)
            
            self.kullaniciBilgiEkrani()

        
        def kullaniciBilgiEkrani(self):
            # self.setWindowTitle("Musteri Bilgileri")

            #tuple'daki verileri değişkenlere atama
            adi = self.kullanici_bilgisi[0][1] # 0 liste içindeki tuple'nı
            soyadi = self.kullanici_bilgisi[0][2]
            email = self.kullanici_bilgisi[0][4]
            telNo = self.kullanici_bilgisi[0][5]
            adres = self.kullanici_bilgisi[0][6]

            print(adi, soyadi, email,telNo,adres)

            # return
            icerik = QVBoxLayout() #main window

            icerik.addWidget(QLabel("Müsteri Adı: ")) #müşteri adı
            self.aranan = QLineEdit()
            icerik.addWidget(self.aranan)
            self.veri = self.aranan.text()

            arama_btn = QPushButton("Ara") #arama butonu
            icerik.addWidget(arama_btn)
            arama_btn.clicked.connect(self.kullaniciBilgiAl)
            
            #aranan isimin bilgilerini yazdır

            araclar = QWidget()
            araclar.setLayout(icerik)
            self.setCentralWidget(araclar)


mainApp = QApplication([])

mainWin = MusteriGoruntule()
mainWin.show()

mainApp.exec()
