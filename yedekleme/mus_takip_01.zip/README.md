# musteri_takip_proje03
Vektörel bilişim 3. projesi
